// CSCI 1300 Fall 2022
// Author: Jacey Fischer
// Recitation: 302 – Michelle Ramsahoye
// Homework 2 - Problem 1

#include <iostream>
using namespace std;

int main() {
    cout << "Hello, World!" <<endl;
    return 0;
}