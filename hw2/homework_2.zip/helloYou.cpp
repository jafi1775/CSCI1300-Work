// CSCI 1300 Fall 2022
// Author: Jacey Fischer
// Recitation: 302 – Michelle Ramsahoye
// Homework 2 - Problem 2

#include <iostream>
#include <string>

using namespace std;

int main() {
    cout << "Please enter your name below: " <<endl;
    string name;
    cin >> name;
    
    cout << "Hello, " << name << "!" <<endl;
    
    return 0;
}