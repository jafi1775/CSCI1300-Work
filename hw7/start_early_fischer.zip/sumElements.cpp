// CSCI 1300 Fall 2022
// Author: Jacey Fischer
// Recitation: 302 – Michelle Ramsahoye
// Homework 7, Problem 2

#include <iostream>
#include <vector>

using namespace std;


int sumElements(vector<int> vec, int start_index, int end_index)
{
    int sum = 0;

    if(start_index > end_index)
    {
        return -1;
    }   
    else if (start_index < 0 || start_index > vec.size() || end_index < 0 || end_index >= vec.size())
    {
        return -2;
    }
    else 
    {
        for (int i = start_index ; i <= end_index; i++)
        {
            sum += vec.at(i);
        }
    }

    return sum;

}




int main ()
{
    return 0;
}